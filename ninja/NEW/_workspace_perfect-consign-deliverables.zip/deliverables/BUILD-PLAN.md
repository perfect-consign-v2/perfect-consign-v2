# Perfect Consign v2 — Build Plan

**Scoped to your constraints:** offline-critical, QuickBooks Desktop export for one tenant, Xero later, no ACH, no online selling.

Prepared as a follow-on to the Round 4 hostile review (`HOSTILE-REVIEW-bdbdb6a.md`). Every workstream below assumes the existing conventions hold: append-only double-entry ledger, `posting_key` uniqueness, schema-per-tenant, forward-only migrations numbered after `016`, `prove_*.sql` proofs wired into `composer check`, PHPStan level 10, 90% coverage floor, 500-line file cap.

---

## Part 1 — Workstreams and sequencing

| # | Workstream | Why it matters | Effort | Depends on |
|---|---|---|---|---|
| 1 | Offline-tolerant POS | Your stated priority. Losing the register when the ISP blips is the single biggest operational risk in a store with a queue at the counter. | 4–6 weeks | Nothing |
| 3 | QuickBooks Desktop export (IIF) | One existing tenant needs it. It is a hard gate for that tenant's renewal. | 2–3 weeks | Nothing (can run parallel to 1) |
| 2 | Consignor portal | Cuts inbound phone calls ("what did I sell?", "when do I get paid?"). Highest perceived value per dollar after offline. | 3–4 weeks | Nothing, but better after 1 so intake data is clean |
| 4 | Markdown ladder + commission tiers | Direct revenue: automated markdowns move aged inventory; tiered commissions let you sign better consignors. | 2 + 2 weeks | Nothing |
| 5 | Booth leases + occupancy | Only relevant if you are running the vendor-mall side. | 3 weeks | Nothing |

**Sequence: 1 → 3 → 2 → 4 → 5.**

Offline first because it protects revenue you already have. QuickBooks second because it is a named, dated commitment to a live tenant. Portal third because it reduces your labor cost permanently. Ladder and tiers fourth because they change money math and deserve a calm, well-tested window. Booth leases last because they are additive and block nothing.

Total elapsed: roughly 16 weeks with one developer, less if workstreams 1 and 3 overlap.

---

## Part 2 — Offline-tolerant POS

The design goal is not "the app works without internet." It is **"a sale that happened at the counter is never lost and never double-posted."** Those are different problems, and the second one is the hard one.

### Architecture

**Local outbox with client-generated idempotency keys.** Every sale, intake, note, and pickup is written to IndexedDB first, with a `posting_key` (UUIDv4) generated *on the client before the network call*. The server's ledger already enforces uniqueness on `posting_key` — that existing constraint is the entire idempotency story. Replay the same sale five times and exactly one journal entry exists. No new dedupe table, no new protocol.

**Batch intake endpoint.** `POST /pos/sync` accepts an array of outbox records and returns per-record results: `accepted`, `duplicate` (already posted, with the journal id), `rejected` (with a reason code), `conflict` (price override needs a permission you do not have offline). Partial success is mandatory — one bad record must not wedge the queue. Rejections surface on a dedicated "needs attention" screen, never silently dropped.

**Price-override permission is the one thing that cannot be resolved offline.** A clerk without override rights who marks something down while disconnected gets `conflict` on sync, and the sale sits pending until a manager approves. Do not cache permissions; the offline copy is always stale and you will get burned.

**Seven-day replay window.** The sync endpoint refuses records older than 7 days with a distinct code, so a tablet lost in a drawer for a month does not inject ancient sales into a closed period. Anything older goes through a manual adjustment with an audit trail.

**Service worker + snapshot.** Cache the shell, the item lookup index, and the current tax and commission config. On reconnect, refresh the snapshot *before* flushing the outbox — never post a sale against a stale commission table.

**Receipt number blocks.** Offline registers must issue receipt numbers that cannot collide. Reserve blocks of 500 per register via the existing `ActiveRegister` mechanism; each device consumes its block locally and reports the high-water mark on sync. Gaps are acceptable and expected. Duplicates are not.

**Posting date = sale date, not sync date.** A sale rung at 5:55pm on the 30th and synced at 9:10am on the 1st posts to the 30th. This is non-negotiable — otherwise month-end close is a lie. The ledger's period rules already allow it if you pass the business date explicitly.

**The close screen must read the local outbox.** If the drawer count screen says "expected cash: $1,240" while $300 of sales are still sitting in IndexedDB, your cash reconciliation is wrong every time the network hiccups. The close screen sums server-side *and* local unsynced records, and labels the difference explicitly.

### Acceptance criteria

- Kill the network mid-sale; the sale completes, prints, and posts exactly once on reconnect.
- Replay the same outbox 10 times; one journal entry, one receipt.
- Two registers offline simultaneously; no receipt number collisions.
- A sale rung on the 30th and synced on the 1st lands in the prior period.
- A clerk without override rights cannot force a markdown offline; the conflict surfaces for manager approval.
- Drawer count includes unsynced sales and says so on screen.

**Effort: 4–6 weeks.** The outbox and sync endpoint are ~2 weeks. The service worker and snapshot are ~1. The receipt blocks and period-date handling are ~1. The close-screen reconciliation and conflict UI are ~1–2. Testing offline is genuinely slow; budget the high end.

---

## Part 3 — QuickBooks Desktop export (IIF)

**Use IIF, not QBXML, not the Web Connector.** QBXML requires QuickBooks to be running and reachable on the same Windows machine; the Web Connector is a fragile SOAP polling daemon that breaks on every QuickBooks update and every Windows update. IIF is a flat text file QuickBooks imports in ten seconds. One-way, month-end, human-triggered. That is the correct amount of engineering for one tenant.

### What it produces

- `journal.iif` — one journal entry per accounting period, with lines mapped from your chart of accounts to the tenant's QuickBooks account names.
- `vendors.iif` — consignor payables as QuickBooks vendors, created or matched by name.
- `reconciliation.pdf` — a human-readable tie-out: your ledger totals by account, the IIF totals, and the delta, which must be zero.

### Schema

`external_account_mappings` — `(provider, chart_role, external_name)` with a unique constraint on `(provider, chart_role)`. `provider = 'quickbooks_desktop'` today. The same table serves Xero later with `provider = 'xero'`, which is why it is generic and not called `qb_accounts`.

### Flow

A settings screen lets the tenant map each of your chart roles to their QuickBooks account names. A job (`QuickBooksExportJob`) generates the three files for a chosen period into object storage, records the file hash, and links it to the period. "Close and export" becomes a single action: it locks the period, generates the files, verifies the reconciliation delta is zero, and refuses to close if it is not. Re-exporting a closed period produces a byte-identical file (same hash) or a loud warning that the period changed.

### Acceptance criteria

- IIF imports into a stock QuickBooks Desktop company file without errors.
- Reconciliation PDF delta is zero for a clean period.
- Re-export of an unchanged period yields the identical hash.
- Closing is blocked when the delta is non-zero.
- A consignor with no prior QuickBooks vendor record is created, not duplicated, on second import.

**Effort: 2–3 weeks.** IIF format quirks (tab-delimited, `!` headers, `ENDTRNS`) are a day. The mapping UI is three days. The exporter and reconciliation are a week. The rest is testing against a real company file, which you should insist on before calling it done.

---

## Part 4 — Consignor portal

**In scope:** magic-link login (no passwords to support), my items with status and photos, my sales, my earnings and pending payout, what is owed to me and when, items about to expire, payout preference (check vs store credit vs hold), and a read-only view of the signed agreement.

**Explicitly out of scope:** self-service intake, chat or messaging, and request-a-payout buttons. All three generate work you do not have staff for and invite disputes you cannot win in writing. Add them later if consignors actually ask.

### Constraints

- **Role-scoped SQL.** Every query runs as a role that can only see its own consignor's rows — not a `WHERE consignor_id = ?` in application code, a database-level guarantee. You already have the role machinery; use it.
- **Rate limits and identical responses.** Magic-link requests always return the same response whether or not the email exists, and are rate-limited per address and per IP. Same discipline you already applied to password recovery.
- **No enumeration.** Item and sale URLs use opaque tokens, not sequential ids.

**Effort: 3–4 weeks.** Auth and the role scoping are a week and a half. The screens are a week. The payout-preference and agreement views are three days. The rest is hardening.

---

## Part 5 — Markdown ladder + commission tiers

### Markdown ladder

`markdown_schedules` — `(tenant, scope, age_days, percent_off, floor_cents, applies_to_category)`. A daily job walks aged inventory, applies the next step, and produces a **re-tag list** (a printable sheet of items whose tags are now wrong) rather than silently changing prices. Floors are hard: no markdown may take an item below its floor without a manager override, and items on hold are skipped.

### Commission tiers

`commission_rules` — `(tenant, scope, priority, effective_from, effective_to, min_price_cents, max_price_cents, rate_bps)`. Scope is consignor, category, or tenant-wide. **One resolution function** decides the rate, and it stores the resolved rate on the sale line at the moment of sale. Never recompute historical commissions from current rules — the rate is frozen onto the line.

**Precedence proof.** This is a money rule, so it gets a `prove_commission_precedence.sql`: overlapping rules, tie-breaking by priority then specificity then effective date, boundary prices exactly at `min` and `max`, and expired rules excluded. If two rules are equally specific and equally prioritized with different rates, the schema must reject the configuration at write time rather than pick one silently.

**Effort: 2 weeks ladder, 2 weeks tiers.** The ladder is straightforward. The tiers are small in code and large in proof surface — budget the time for the proof, not the feature.

---

## Part 6 — Booth leases + occupancy

`booth_leases` — `(tenant, booth_id, tenant_contact, start_date, end_date, monthly_rent_cents, deposit_cents, status)`, with a PostgreSQL **exclusion constraint** on `(booth_id, daterange)` so two overlapping active leases on one booth are physically impossible. Rent is generated from leases by the existing job runner, not entered by hand. An occupancy screen shows every booth as occupied / vacant / delinquent / lease-ending-soon, with the rent roll and the delinquency list.

You already have `2151 booth_deposit_held` and the overdraw-refusing trigger from the last round, so deposits are handled.

**Effort: 3 weeks.** The exclusion constraint and rent generation are a week. The occupancy screen and delinquency logic are a week. The rest is the lease document view and edge cases (mid-month starts, prorating, early termination).

---

## Part 7 — Deferred items, with hooks built now

Do not build these, but do not design yourself into a corner either.

- **ACH payouts** — add `payout_method` and `payment_reference` columns to the payout table now, defaulted and unused. When you do want ACH, the data model is already there.
- **Xero** — `external_account_mappings` is already provider-generic. A Xero exporter is a new provider value and a new file writer, not a schema change.
- **Online selling** — add `listed_state` and `channel` to items now (defaulted to `in_store` / `none`). When you list online, you are populating columns, not migrating a table.
- **1099 reporting** — a report over existing payout data. No schema work needed; do it when a consignor crosses the threshold.
- **Mobile intake** — the batch intake endpoint from Part 2 is the same endpoint a phone camera app would use. You get the API for free.
- **Donation receipts** — a document template over existing item and consignor data.

---

## Part 8 — Schedule, definition of done, and CI

**16-week schedule:** Weeks 1–6 offline POS. Weeks 4–6 QuickBooks in parallel. Weeks 7–10 consignor portal. Weeks 11–14 markdown ladder and commission tiers. Weeks 15–16 booth leases, with slack absorbed wherever it lands.

**Definition of done, per workstream:**

1. Every money rule has a `prove_*.sql` proof, wired into `bin/prove-suite.php` and `composer check`.
2. Every new route has a real HTTP test that exercises the actual controller against the actual database — not a stub.
3. The edited path is executed by hand once before the branch is called done. SQL gets run through PDO, not eyeballed.
4. No new file exceeds 500 lines; PHPStan stays at level 10; coverage floor stays at 90%.
5. Migrations are forward-only and numbered after `016`.

**One CI addition:** add a single `php bin/work.php` pass to CI, against a seeded database, asserting that jobs finish and none dead-letter. Right now the worker is the least-tested path in the system and it is the one that touches money (late fees, digests, reconciliation). That is the cheapest risk reduction available to you.

---

## Appendix — Why this order and not another

The tempting order is portal first, because it is the most visible to your consignors. It is the wrong order. The portal shows consignors their sales; if the register loses a sale during a network blip, the portal shows them the wrong number and you have converted a technical problem into a trust problem. Fix the floor before you open the window.

The second temptation is commission tiers first, because they are pure revenue. But tiers change the math on every historical sale line if you get the freezing wrong, and retroactive commission errors are the single most expensive class of bug in a consignment system — you have to phone people and take money back. Do it in a calm window with a precedence proof, after the register is trustworthy.

QuickBooks sits second only because it is a promise already made to a live tenant. If that tenant's renewal is not actually at risk, move it after the portal and pull the schedule in by two weeks.
