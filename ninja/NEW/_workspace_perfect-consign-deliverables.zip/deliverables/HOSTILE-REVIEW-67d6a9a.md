# Hostile Review — perfect-consign-v2 @ `67d6a9a`

**Reviewer posture:** adversarial. I am playing the engineer a competitor hires to kill this deal, and the auditor a store owner hires after a cash variance. I am not looking for reasons to be pleased. Every finding below cites a file and line in the tree at `67d6a9a`.

**Scope of this review:** the 13 commits between `bcc55ba` and `67d6a9a` (182 files, +13,685 / −11,522), plus the blast radius of those commits into the rest of the system. `MASTER-PLAN.md` was used as the claim set to test against — where the plan says "proven", I checked whether the proof is real.

**Method and its limits:** this is a source-reading review. **PHP is not installed in this sandbox**, so `composer check`, PHPUnit, and the `prove:*` suites could not be executed here. Every claim below is grounded in code, SQL, or CI configuration that I read directly. Where I say "this will fail", I am describing what the code does, not what a test run showed. That limitation is itself finding **C2-adjacent**: a system whose quality gates cannot be run outside one specific machine is a system whose gates are aspirational.

---

## Verdict

The ledger kernel survived the schema collapse intact — that is the good news and it is real news. The append-only double-entry core, the `ENABLE ALWAYS` triggers, the reversal-only posting model, and the `account_balances` view all came through the 68-files-to-2-files collapse without losing their guarantees.

The batch around it, however, introduces **one committed live credential, one irreversible upgrade break, one destructive button wired to the production demo, one silent permanent loss of referential integrity, and one double-pay path in a money operation.** It also weakens one of the quality gates that is supposed to prevent exactly this class of mistake, and adds a set of tests that cannot fail.

**Counts: 5 critical, 8 high, 12 medium, 7 low.**

> **Update:** the gates in this document have since been executed against PHP 8.5.12 and PostgreSQL 18.6. See `HOSTILE-REVIEW-RUN-RESULTS.md`. All five criticals were reproduced; **H6 was tested and withdrawn as incorrect**; two new findings were added (N1 coverage, N2 parallel-safety).

If I were the competitor's engineer, my one-line summary to the buyer would be: *"They deleted their migration history, committed a Gmail password, put a wipe button on their live demo, and their tests assert that method names exist."* Every one of those is defensible in isolation and indefensible together.

---

## CRITICAL

### C1 — A live Gmail app password is committed to the repository

`sql/dev_tenant.sql:5-6`:

```sql
UPDATE public.mall
SET receipt_mail_via = 'gmail',
    gmail_address = 'benanamen@gmail.com',
    gmail_app_password = 'rtxlnmaxtzfjvjno';
```

This is not a placeholder. It is a 16-character Google app password in the exact format Google issues, paired with a real-looking Gmail address. It has been in git history since `428baff` ("Email sale receipts from the server or a mall Gmail account"). It is loaded into a tenant by `src/Feature/Dev/DevTenantReset.php:79-89`, which executes this file verbatim.

The blast radius is worse than "a dev seed leaked". The same mailbox is the fallback identity for **password resets**: `src/Feature/Password/LoginAccounts.php:116-133` (`forReset()`, `companyMail()`) reads `gmail_address` / `gmail_app_password` from `$schema.mall` and `ResetLetter::deliver()` uses them to send reset mail. So the credential that is in the repo is the credential that can send mail *as the store*, to the store's owners, from the store's domain reputation. An attacker with this password can send convincing reset-phishing from the real mailbox, or simply read the mailbox if IMAP is enabled on the account.

**Why it is critical, not high:** it is committed, it is live-shaped, it is in history (so deleting the file does not delete the secret), and it is wired to the authentication recovery path.

**Fix:** revoke the app password in Google account settings *today* (before anything else in this document). Then purge history with `git filter-repo --path sql/dev_tenant.sql --invert-paths` or `--replace-text`, force-push, and have every clone re-clone. Replace the seed with an environment variable read (`STALL_DEV_GMAIL_APP_PASSWORD`) and a `.env.example` that carries a fake value. Add `gitleaks` or `trufflehog` as a `composer check` step so the next one is caught at commit time, not at review time.

### C2 — There is no upgrade path; every existing database is told to "create a new database"

Three separate places now refuse to work on a database built by an older schema:

- `src/Schema/SchemaMigrator.php:28` — `throw new RuntimeException('this database was built by an older schema; create a new database');`
- `src/Schema/TenantMigrator.php:30` — `throw new RuntimeException('tenant ' . $slug . ' was built by an older schema; create a new database');`
- `src/Schema/MigrationRecord.php:68` — `throw new RuntimeException($file . ' is from an older schema; create a new database');`

The functions that used to make an old database adopt the new baseline — `finishPlatform()`, `platformBaseline()`, `stampPresent()`, `baselineTenant()`, `tenantBaseline()` — have been **deleted**. `TenantMigrator` now just checks `to_regclass($schema.journals)` and otherwise throws.

This is the single most damaging architectural decision in the batch, and it is disguised as a simplification. The collapse from 68 numbered tenant migrations to `001_tenant.sql` is defensible for a greenfield build. It is not defensible as the *only* path, because:

1. Any store running a build at or before `bcc55ba` — including the demo, including any pilot — cannot be upgraded. Their data is stranded behind a `RuntimeException`.
2. The system's stated law, repeated throughout the codebase and the plan, is **"append-only, forward-only migrations"**. That law is now false. The migration set is not append-only; it was rewritten wholesale, and the checksum machinery's answer to "the file changed" is "start over".
3. `bin/deploy-demo.sh` works around this by *wiping the tenant* when it sees "changed after it was applied" — which is finding **C3** colliding with **C2**. The deploy script's recovery strategy for a migration mismatch is data destruction.

**Why it is critical:** a POS system's entire value proposition is that the store's books are durable. "Create a new database" is the opposite of durable. A competitor's engineer will ask one question — *"what happens to my data when you ship an update?"* — and this code answers it badly.

**Fix:** restore a real upgrade path before any tenant other than the demo exists. Minimum viable: a `platform.schema_baseline` row recording which collapsed file each tenant was built from, plus a documented, tested `bin/upgrade.php` that runs the delta. If the honest answer is "we are pre-production and will wipe", then say that explicitly in the README and *remove the demo from the equation* (C3) so nobody confuses the demo's wipe-on-mismatch behavior with a supported upgrade.

### C3 — A one-click "wipe everything" button is live on the production demo

`src/Shared/Web/layout.php:36`:

```php
$resetTestData = ($slug === 'dev' || $slug === 'mall') && $actorRole === 'owner';
```

`src/Shared/Web/layout.php:256-262` renders a danger button that POSTs to `/{slug}/reset-test-data`. `src/Feature/Dev/DevResetController.php:26-45` handles it behind `checkCsrf()` and `allowed()` (role `owner`, slug match, slug ∈ {`dev`, `mall`}). `src/Feature/Dev/MallTenantReset.php:15-31` then calls `wipeTenant()` + `provision-tenant` + `MallDemo->load()`.

The slug `mall` **is the live demo**. I verified `https://v2.perfectconsign.com/mall` returns HTTP 200 and that the button is rendered for that slug. So the production demo has a button, one `confirm()` dialog deep, that drops the tenant schema and rebuilds it.

`MallTenantReset::replacementOwner()` (`:55-65`) falls back to the hardcoded password `'mall-demo'` when `STALL_OWNER_PASSWORD` is unset — so after a wipe, the demo comes back up with a known password.

**Why it is critical:** the gate is *slug string comparison compiled into every deployment*. There is no environment flag, no `APP_ENV`, no config toggle. Anyone who can guess that `mall` is a demo slug — and the URL is public — and who has or obtains an owner session, can destroy the demo. More importantly, the pattern is a landmine: the day someone provisions a real tenant with a slug that happens to match the allowlist, or copies this layout into a build without the allowlist, the button ships to a paying customer.

**Fix:** remove the button from `layout.php` entirely. Move the reset capability to a CLI command (`bin/reset-tenant.php`) that requires shell access. If a demo reset button is genuinely wanted, gate it on an environment variable that is set only in the demo deployment (`STALL_DEMO_RESET=1`) and make the controller check that variable, not the slug. Delete the hardcoded `'mall-demo'` fallback; a reset with no configured password should fail loudly.

### C4 — `bin/wipe-tenant.php` permanently drops two platform foreign keys and never restores them

`bin/wipe-tenant.php:75` and `:94`:

```php
$pdo->exec('ALTER TABLE platform.password_resets DROP CONSTRAINT ' . $constraint);
$pdo->exec('ALTER TABLE platform.owner_backups DROP CONSTRAINT ' . $constraint);
```

The function finds the FK from `platform.password_resets` → `platform.tenants` and from `platform.owner_backups` → `platform.tenants`, and drops it. **Nothing in the file, and nothing in the provisioning path, re-adds these constraints.**

The reason for the drop is understandable: you cannot delete a `platform.tenants` row while child rows reference it. But the fix is to delete the child rows (which the function already does for `owner_sign_in_failures`, `password_reset_requests`, `owners`) and then `DROP SCHEMA ... CASCADE`, not to amputate the constraint. After one wipe, `platform.password_resets` and `platform.owner_backups` can reference tenants that do not exist — permanently, for every tenant in the database, not just the wiped one.

**Why it is critical:** this is silent, permanent, database-wide referential-integrity loss triggered by an operation (C3's button, and `bin/deploy-demo.sh`'s mismatch recovery) that is expected to be routine. It will never throw. It will show up months later as orphaned rows in a backup or a reset flow that resolves to a tenant that was deleted.

**Fix:** delete the child rows and let the FK do its job. If a constraint genuinely must be deferred, use `ALTER TABLE ... DROP CONSTRAINT ...` inside the same transaction that re-adds it, or better, `SET CONSTRAINTS ... DEFERRED`. Add a `prove` check that asserts the FK exists after a wipe.

### C5 — Store use is the only money operation with no idempotency key

`src/Feature/Payout/StoreUse.php:35`:

```php
$reference = bin2hex(random_bytes(16));
return $this->ledger->post(new JournalDraft(
    postingKey: 'store-use:' . $reference, ...));
```

Every other money path in this system earns its keep with a deterministic posting key: late fees use `'late-fee:' . $booth . ':' . $period . ':' . $ordinal` (`LateFee.php:post()`), sales use a ticket-derived key, reversals use `'reversal:' . $journalId`. That is what makes them safe against double-submit, retry, and the browser back button.

Store use generates a **random** key. Two clicks, a double POST, a retry after a timeout, or a resubmitted form all produce different keys and therefore **different journals** — each one debiting `store_purchases` and crediting `vendor_payable`. The vendor is paid twice, and the ledger has no way to know it was a duplicate because the keys differ.

`StoreUseController` does call `checkCsrf()` — but CSRF tokens prevent *cross-site* forgery, not *double submission of a legitimate form*. The token is valid for both clicks.

**Why it is critical:** it is a money operation, it is reachable from the UI, and the failure mode is silent overpayment that the books will faithfully record as real.

**Fix:** derive the key from the business event, not from randomness. The natural key is the item being purchased (or an explicit user-supplied reference): `'store-use:' . $itemId` or `'store-use:' . $vendorId . ':' . $itemId . ':' . $date`. If a vendor can legitimately buy the same item twice, require an explicit reference field and key on it. Then the unique posting key does the deduplication for free, exactly as it does for late fees.

---

## HIGH

### H1 — The job worker runs as the database superuser

`bin/work.php:26-40` connects using `STALL_DB_USER`, which is the `stall` role — the schema owner and superuser. `src/Shared/Jobs/JobRunner.php:60-75` then does `SET search_path TO $schema` and dispatches to jobs that have full write authority.

The rest of the system went to considerable trouble to run the web tier as `stall_app` and to restrict journal writes to `stall_poster` (insert-only). The worker bypasses all of that. Every job — late fees, reconciliation, digests, rent reminders — executes with the authority to drop tables, alter the schema, and rewrite history. A bug in a job's SQL is not a bug in a tenant; it is a bug in the database.

**Fix:** run the worker as a dedicated role with exactly the grants the jobs need (the `stall_poster`-style insert-only grant plus `SELECT` on `platform.jobs` plus the specific function `EXECUTE` grants). The `platform.create_poster()` / `grant_poster_jobs()` machinery in `sql/003_poster_jobs.sql` already exists to make this easy — use it for the worker too.

### H2 — A failed job is marked finished and never retried

`src/Shared/Jobs/JobQueue.php:78-83`:

```php
UPDATE platform.jobs
SET finished_at = clock_timestamp(), locked_by = NULL, error = ?
WHERE id = ?::uuid
```

`JobRunner::pass()` catches `Throwable`, logs it, and then calls `finish()` regardless. So a job that throws is recorded as finished with an error string. There is **no retry, no attempt ceiling, no dead-letter state, and no alerting.** `attempts` exists as a column but nothing increments it in a way that drives behavior.

Compounding it: `src/Shared/Jobs/DigestJob.php:30-55` loops over vendors and calls `$this->mail->deliver(...)` with **no per-vendor try/catch**. One SMTP failure — one bad address, one greylist — aborts the entire loop, and because of the `finish()` behavior above, the remaining vendors are never emailed and the job is marked done.

**Why it is high:** the jobs are the unattended half of the business. Late fees that silently stop posting, digests that silently stop sending, reconciliations that silently stop checking — each is invisible until a store owner notices money is wrong. A job system without retries and without alerting is a cron job with extra steps.

**Fix:** increment `attempts`, retry with backoff up to a ceiling, move exhausted jobs to a dead-letter state (`finished_at IS NULL, attempts >= N, error IS NOT NULL`), and alert on dead-letter count. Add per-recipient try/catch in `DigestJob` so one failure does not abort the batch. Add a `prove` assertion that a throwing job is retried.

### H3 — `enqueue()` has a check-then-insert race that aborts the pass

`src/Shared/Jobs/JobQueue.php:28-40` uses:

```sql
INSERT INTO platform.jobs (...) SELECT ... WHERE NOT EXISTS (...)
```

with no `ON CONFLICT`. Two workers scheduling the same daily job at the same moment both pass the `NOT EXISTS` check and both attempt the insert; the unique index `jobs_tenant_kind_day_key ON (tenant, kind, (payload->>'date'))` rejects the second with `23505`, which propagates out of `enqueue()` and aborts the scheduling pass for that tenant.

**Fix:** `ON CONFLICT (tenant, kind, (payload->>'date')) DO NOTHING`. One line, removes the race entirely. The `WHERE NOT EXISTS` can stay or go; the `ON CONFLICT` is the actual guarantee.

### H4 — Enabling late fees retroactively bills every historical unpaid period

`src/Feature/Rent/LateFeeDue.php:74-95, 97-110`. `slots()` starts at the period start (`lateOn($start, $grace)`), steps forward by the grace period, and continues until `$today` or the period end. `apply()` then posts every slot it finds, **dated today** (`:47-53`).

So the day a store turns late fees on, the job walks back through every unpaid period since the beginning of time (or the beginning of the rental history) and posts a fee for each one, all dated today. A store that has been running for two years and flips the switch gets two years of late fees posted in one night.

This was previously gated behind a manual button, where the operator could see what was about to happen. Commit `48ac321` ("Drop the manual late-fee button so only the daily job posts them") removed that gate. Now it runs unattended, daily, for every tenant.

**Fix:** add a `late_fees_start_date` (or `policy_effective_from`) to the mall settings and have `slots()` refuse to start before it. Default it to the date the feature is enabled. The policy should be forward-looking; retroactive billing is a business decision that must be explicit, not a side effect of a settings toggle.

### H5 — The demo deploys on every push, without waiting for `check`

`.github/workflows/deploy-demo.yml` triggers on `push: branches: [master]` and `workflow_dispatch`, with **no `needs:`** on the check workflow. Commit `5bb1bd6` is literally titled "Deploy the demo on every master push, without waiting for check."

So a commit that fails PHPStan L10, fails the mutation suite, or fails `prove:race` still goes to `https://v2.perfectconsign.com/mall` within minutes. Combined with C3 (the wipe button) and C2 (wipe-on-mismatch in `bin/deploy-demo.sh`), the demo can be destroyed by a broken commit and rebuilt from a broken schema.

**Fix:** `needs: check` on the deploy job, or at minimum a `workflow_run` trigger that fires only on `conclusion == success`. The demo is the artifact a buyer looks at; it should never be the first place a defect is observed.

### H6 — WITHDRAWN (tested and found incorrect)

The original claim was that `bin/prove-obligations.php:38` (`$file > '001_tenant.sql'`) narrowed the obligation scanner until it checked nothing.

**This was tested and is wrong.** Removing `SELECT public.stall_seed_export_accounts();` from `sql/007_vendor_memo.sql` — the only call site — makes the gate fail with `007_vendor_memo.sql adds a chart role and does not call stall_seed_export_accounts()`. `007` adds a chart role and sorts after `001_tenant.sql`, so the obligation is enforced there.

The residual, lower-severity observation: the rule is vacuous for `001_tenant.sql` itself, which adds 24 chart roles but is exempt by the string comparison. That is a latent maintenance risk, not a current defect. See the addendum for the full test.

### H7 — The migration checksum silently rewrites itself

`src/Schema/MigrationRecord.php:65-90, 123-142`. When the current checksum differs from the stored one, the code calls `sameAsideFromNewlines()`; if the only difference is LF vs CRLF, it accepts the file and then calls `replace()` — which **UPDATEs the stored checksum to the new value**, with no audit row and no log line.

The newline tolerance is reasonable (Windows checkouts, `core.autocrlf`). The silent rewrite is not. A checksum's entire purpose is to detect that a file changed after it was applied. Silently updating it to match means the next change — a real one — will be compared against a checksum that was itself never reviewed.

**Fix:** keep the newline tolerance, but write an audit row (`platform.migration_checksum_rewrites` or the existing `audit_events`) recording old value, new value, file, and timestamp. Or, better, normalize line endings on read so the checksum is stable and no rewrite is ever needed.

### H8 — The audit trail is decorative

`src/Bootstrap/AuditLog.php:17-25` defines `record($actor, $role, $action, $entityType, $entityId)`. It silently returns if any field is empty. `request_id` is `bin2hex(random_bytes(8))` — a fresh random value, not the actual request id, so it cannot be correlated with logs.

There is exactly **one call site** in the entire codebase: `src/Feature/Company/CompanyController.php:39` (`'settings.edit', 'company'`). Sales, voids, discounts, payouts, rent waivers, register closes, permission changes, password resets — none of them write an audit event. The `audit_events` table exists, has a CHECK on role, and has no-delete/no-truncate triggers, which makes it look like an audit system. It is not one.

**Why it is high:** "who voided this sale and when" is a question every consignment store asks, and the system cannot answer it.

**Fix:** wire `AuditLog::record()` into every state-changing command (`SalePoster`, `SaleVoid`, `TenderSplit`, `Payout`, `LateFee::waive`, `RegisterClose`, `CompanyController`, password reset). Pass the real request id through from `Request`. Make the empty-field early return throw in non-production so missing context is caught in tests.

### H9 — The new `Permission` verb list is used in exactly one place

`src/Bootstrap/Permission.php` defines `VERBS` (sale.post, sale.void, sale.discount, sale.tax_free, payout.disburse, rent.waive, register.close, settings.edit) and `allows()`. The only production call site is `src/Feature/Report/ReportsController.php:52`.

Actual authorization is still `src/Bootstrap/RoleGate.php`, which does path-prefix allowlisting per role. So there are now **two sources of truth** for who can do what, and they are not derived from each other. The `Permission` class looks like the future and is, today, a second opinion nobody consults. The plan's own language ("must agree") is a maintenance instruction, not an enforced invariant.

**Fix:** either finish the migration (make `RoleGate` consult `Permission` for every verb) or delete `Permission` until you are ready. A half-migrated authz model is worse than either end state, because reviewers will assume the new one is load-bearing.

---

## MEDIUM

### M1 — Three of the new tests cannot fail

- `tests/Feature/Jobs/PhaseCallsTest.php:11-18` asserts that a **hardcoded string** contains `'pass('`, `'assess('`, `'numbers('`. It does not read the source, does not call the code, and would pass if the entire job subsystem were deleted.
- `tests/Feature/Payout/StoreUseTest.php:9-13` asserts only `method_exists(StoreUse::class, 'record')`, plus a comment that spells out the method names it wishes it were testing (`// vendors( itemId( page( form( submit(`). This is the test for the money operation in **C5**.
- `tests/Feature/Rent/LateFeeDueTest.php` is genuinely good — grace periods, month keys, second-fee amounts, period resets, already-posted skips, disabled paths — **except** `testAPeriodEndsTheDayBeforeTheNextMonthAndSlotsStopThere`, which uses reflection to assert that method names exist.

A test that asserts a string literal contains a substring is not a test. It is a comment with a green checkmark. In a system that markets "proven" as a property, this is the finding that does the most reputational damage.

**Fix:** delete the fake tests. For store use, write a test that posts twice with the same business key and asserts one journal. For the job phase, write a test that runs `JobRunner::pass()` against a real (containerized) database and asserts a job was claimed and finished.

### M2 — SMTP headers are interpolated without CRLF stripping

`src/Shared/Mail/SmtpClient.php:118-140`. `payload()` interpolates `$from`, `$to`, and `$subject` directly into header lines. There is no stripping of `\r` / `\n`. A vendor name or subject containing a newline can inject arbitrary headers (`Bcc:`, `Content-Type:`). There is also no `Date:` and no `Message-ID:` header, which hurts deliverability and makes messages un-threadable.

**Fix:** strip `[\r\n]` from every header value, and add `Date:` (RFC 2822) and `Message-ID:` (random, domain-qualified).

### M3 — Reset mail failures are swallowed

`src/Feature/Password/ResetLetter.php:44-62` wraps the send in `catch (\Throwable) { $this->logger->error('reset mail was refused'); }`. The user is told the reset was sent; the operator gets one log line. If Gmail starts rejecting the app password (which it will, if C1 is fixed by revocation), password recovery silently stops working and nobody knows until a locked-out owner calls.

**Fix:** surface a distinct user-facing message when delivery fails, and alert on the error (see H2's alerting requirement).

### M4 — Owner password reset falls back to a shared company inbox

`src/Feature/Password/LoginAccounts.php:116-133`. `forReset()` falls back to the company email when an owner has no email of their own. So anyone who can read the company inbox can reset any owner account that lacks a personal address — including owners who never set one precisely because they expected the inbox to be shared with staff.

**Fix:** require a per-owner email for reset eligibility, or explicitly mark the fallback as a lower-trust path and log it. Do not silently upgrade inbox access into owner access.

### M5 — The Gmail app password is stored in plaintext in the database and in backups

`sql/001_tenant.sql:3535-3536` (`gmail_address`, `gmail_app_password` as `text`), written by `ReceiptMailSettings.php:57-59`. The mall CHECK constraint only enforces length and alphanumeric shape; it does not encrypt. So the credential is in the tenant schema, in every `pg_dump`, and in every backup — including the `stall_backup` read-only role's reach.

**Fix:** encrypt at rest (pgcrypto or application-level with a KMS/env key), or move the credential to a secret store and keep only a reference in the DB.

### M6 — CSV export is unescaped and formula-injectable

`src/Feature/Report/ReportsController.php:36-46` echoes `code,account_type,balance_minor` with no `fputcsv` and no formula-injection guard. A chart-of-accounts code beginning with `=`, `+`, `-`, or `@` will execute as a formula when the CSV is opened in Excel. This is a well-known class of bug and it is trivially avoidable.

**Fix:** use `fputcsv`, and prefix any cell beginning with `= + - @` with a single quote.

### M7 — `.cursor/rules/` is still shipped

The repo contains `do-not-run-tests.mdc`, `git-do-not-mention-idea-leftovers.mdc`, `maintain-proven-level.mdc`, `prove-before-advance.mdc`, and `update-demo-on-push.mdc`. A rule file named **"do not run tests"** in a repository that sells itself on proof is, at minimum, an optics problem, and at worst an instruction that shaped the fake tests in M1. `update-demo-on-push.mdc` is the policy that produced H5.

**Fix:** remove `.cursor/rules/` from the repository, or move it to a local-only ignore. It is not part of the product.

### M8 — `overdue()` is inverted

`src/Shared/Jobs/JobQueue.php:85-99` counts jobs where `run_at < clock_timestamp() - interval '15 minutes'` **including locked jobs**. So a job that is legitimately running for 16 minutes is reported as overdue, while a job that failed and was marked finished (H2) is not reported at all. The metric measures the wrong thing in both directions.

**Fix:** overdue = `finished_at IS NULL AND locked_by IS NULL AND run_at < now() - interval`. Stale-lock reclaim is a separate query.

### M9 — `platform.jobs` grants do not allow the web tier to enqueue

`sql/002_platform_jobs.sql:23` grants `SELECT` only to `stall_app`; `sql/004_job_grants.sql:3` grants `SELECT` only to `stall_poster`. Neither has `INSERT`. Only the superuser (used by `bin/work.php`, see H1) can insert. So any web-side enqueue — a "send receipt now" button, a manual reconcile — will fail with a permission error.

**Fix:** decide who enqueues. If it is the web tier, grant `INSERT` on `platform.jobs` to `stall_app` (and consider a `SECURITY DEFINER` enqueue function so the grant is narrow).

### M10 — `ReconcileJob` proves the view, not the report

`src/Shared/Jobs/ReconcileJob.php:15-22` calls `stall_refuse_report_drift(viewTotal, lineTotal)`, where `viewTotal` is `COALESCE(sum(balance_minor),0) FROM account_balances` and `lineTotal` recomputes from `journal_lines` (`BooksReport.php:33-56`). That proves the view agrees with the lines. It does **not** prove the report the user sees agrees with either, because the report is assembled by `BooksReport::rows()` from the same view. If `rows()` has a bug, the reconciliation is green and the report is wrong.

**Fix:** reconcile the rendered report total against the ledger, not the view against the ledger.

### M11 — Late-fee journals are all dated "today"

`src/Feature/Rent/LateFeeDue.php:47-53` posts every slot with today's date, discarding the computed slot date. A fee that should have been assessed on the 5th is dated the 17th. The books are arithmetically correct and chronologically wrong, which makes period reporting misleading and makes it impossible to reconstruct what the store actually owed on any given day.

**Fix:** post each fee with its slot date (the date the fee became due), subject to the period being open.

---

## LOW

- **L1** `sendJson()` is duplicated verbatim in `PosController` and `PosPayController`. Extract to a trait or base controller.
- **L2** JSON responses carry no `Cache-Control: no-store`. Sale and ticket payloads are user-specific and should not be cached by intermediaries.
- **L3** `StoreUse::itemId()` (`StoreUse.php:69-88`) returns `null` for an empty code, so a store use can be recorded against no item at all. That may be intentional (miscellaneous purchase) but it should be explicit, not the default of an empty string.
- **L4** `sql/dev_tenant.sql` seeds real-looking vendor identities and a real Gmail address. Even after C1 is fixed, use obviously fake data (`vendor@example.invalid`).
- **L5** `MallTenantReset::replacementOwner()` (`:55-65`) hardcodes the fallback password `'mall-demo'`. A reset with no configured password should fail, not fall back.
- **L6** The README is Windows-oriented (PowerShell paths, `php.exe`). The deploy target is Linux/Plesk. A new engineer on a Mac or Linux box will hit friction on step one.

---

## What is genuinely good (and should not be lost in the noise)

I want to be precise about this, because a hostile review that finds nothing good is a bad review.

- **The ledger kernel survived the collapse.** `sql/001_tenant.sql` still contains 89 `ENABLE ALWAYS` triggers; `sql/000_platform.sql` contains 10, and the event triggers that guard append-only behavior were correctly relocated to the platform file because they are database-wide, not tenant-scoped. `account_balances` is still a view over `journal_lines` (line 5288), not a stored balance. The reversal-only model and the unique posting keys are intact. This is the hardest part of the system to get right and it came through a 7,000-line rewrite without losing its guarantees.
- **Late fees are properly idempotent.** `LateFee::post()` derives the posting key from booth, period, and ordinal, and returns the existing journal id if the key already exists. That is exactly the pattern C5 is missing. `LateFeeDueTest` tests this for real.
- **`stall_refuse_report_drift()` lives in the database**, not in application code. A reconciliation that can be bypassed by not calling it is not a reconciliation; putting it in PL/pgSQL was the right call.
- **The migration freeze is real and wired into `composer check`** (`bin/check-migration-freeze.php`, `tests/Shared/MigrationFreezeTest.php`). Its limitation — it compares against `origin/master`, so it is a no-op on master itself — is a real gap, but the mechanism is sound and the test is a real test.
- **`wantsJson()` and the JSON sale path reuse the existing command layer** (`SalePoster`, `SaleCheckout`, `SaleHold`, `TenderSplit`). The register did not grow a second, parallel sale path; it grew a second transport. That is the correct shape.
- **`notFound()` avoids an existence leak** in `ReportsController`. Small, correct.

---

## The three things a competitor will say

1. **"They deleted their migration history and replaced it with 'create a new database'."** (C2)
2. **"Their job runner is a superuser cron with no retries and no alerting."** (H1, H2)
3. **"Their tests assert that method names exist."** (M1)

Each of these is answerable. None of them is answerable *while the code says what it currently says*.

---

## Suggested order of work

**Today (before anything else):**
1. Revoke the Gmail app password (C1).
2. Purge it from git history and force-push (C1).
3. Add a secret scanner to `composer check` (C1).

**This week:**
4. Remove the reset button from `layout.php`; move reset to CLI (C3).
5. Remove the hardcoded `'mall-demo'` fallback (C3, L5).
6. Fix `wipe-tenant.php` to delete child rows instead of dropping FKs (C4).
7. Give store use a deterministic posting key (C5).
8. Add `needs: check` to the demo deploy (H5).

**Next:**
9. Run the worker as a least-privilege role (H1).
10. Add retry, attempt ceiling, dead-letter, and alerting to the job system (H2).
11. `ON CONFLICT DO NOTHING` in `enqueue()` (H3).
12. Add a late-fee policy start date (H4).
13. Close the coverage gap: add the 19 zero-coverage files to the floor, and run coverage in `composer check` (N1).
14. Audit-row the checksum rewrite (H7).

**Then:**
15. Replace the fake tests with real ones (M1).
16. Wire `AuditLog` into every state-changing command (H8).
17. Resolve the `Permission` / `RoleGate` duplication (H9).
18. Encrypt the mail credential at rest (M5).

**Before any real tenant:**
19. Decide and document the upgrade story (C2). If the answer is "we wipe", say so and remove the demo from the supported path. If the answer is "we upgrade", build and test it.

---

*Review conducted against `67d6a9a`. PHP was not available in the review environment, so no test suite was executed; all findings are from direct reading of source, SQL, and CI configuration. Line numbers refer to that commit.*
