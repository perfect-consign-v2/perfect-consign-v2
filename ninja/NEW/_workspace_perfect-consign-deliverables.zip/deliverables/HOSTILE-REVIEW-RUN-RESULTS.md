# Hostile Review — Execution Addendum

**Companion to:** `HOSTILE-REVIEW-67d6a9a.md`
**Commit:** `67d6a9a`
**Purpose:** The first review was source-reading only, because PHP was not installed. This document replaces "I could not run it" with actual execution results, and corrects the findings that turned out to be wrong.

---

## 1. Environment

The stack was installed to match the project exactly, not approximately:

| Component | Version | Source |
|---|---|---|
| OS | Debian 12 (bookworm) | sandbox |
| PHP | **8.5.12** (NTS) | Sury repo |
| Extensions | pdo_pgsql, mbstring, xml, curl, zip, intl, bcmath, sqlite3, xdebug 3.5.3 | Sury |
| PostgreSQL | **18.6** | PGDG |
| Composer | 2.10.3 | getcomposer.org |
| Database | `consign` on `127.0.0.1:5436`, user `stall`/`stall` | matches `docker-compose.yml` and `check.yml` |

Provisioning sequence was replicated from `.github/workflows/check.yml`: `php bin/provision-platform.php`, then `php bin/enable-stall-app.php`, then the suites.

---

## 2. `composer check` — every gate passes

Run step by step so failures could be attributed, not hidden behind a single exit code.

| Step | Result | Detail |
|---|---|---|
| `check:freeze` | **PASS** | `ok migration freeze` |
| `check:max-lines` | **PASS** | all `src` files under 500 lines |
| `check:phpmd` | **PASS** | no output (clean) |
| `phpstan` (L10) | **PASS** | `[OK] No errors`, 398 files |
| `test` (unit) | **PASS** | 716 tests, 2,902 assertions, 11.1s |
| `test:integration` | **PASS** | 27 tests, 223 assertions, 74.7s |
| `test:http` | **PASS** | 76 tests, 1,169 assertions, 233s |
| `prove:obligations` | **PASS** | `ok obligations` |
| `prove:race` | **PASS** | `ok race` |
| `prove` | **PASS** | 55 proof files, all `ok` |
| `prove:tenant` | **PASS** | exit 0 |

**Total: 819 tests, 4,505 assertions, all green.** The gates are not fake. That is the honest headline, and it makes the findings below worse rather than better: every critical defect in the original review survives a fully green `composer check`.

---

## 3. Coverage — the 90% floor is met, and 19 files sit at 0%

`php bin/coverage-run.php` (with xdebug), clean single-database cluster:

```
OK (819 tests, 4505 assertions)
Lines: 19054/20371 (93.53%)
COV_EXIT=0
```

93.53% clears the 90% floor. But the floor is **aggregate**, so new code hides under well-tested old code. Nineteen files report **0.0%**:

```
0.0%  0/ 13  Feature/Report/reports.php
0.0%  0/ 14  Feature/Pos/desk.php
0.0%  0/ 17  Feature/Payout/store-use.php
0.0%  0/ 17  Feature/Report/ReportsController.php
0.0%  0/ 20  Feature/Pos/ReceiptEmailController.php
0.0%  0/ 20  Shared/Jobs/DigestJob.php
0.0%  0/ 21  Feature/Report/BooksReport.php
0.0%  0/ 22  Feature/Book/missed-sale.php
0.0%  0/ 23  Feature/Book/vendor-memo.php
0.0%  0/ 26  Feature/Pos/ReceiptMailer.php
0.0%  0/ 30  Feature/Payout/StoreUseController.php
0.0%  0/ 35  Shared/Jobs/JobRunner.php
0.0%  0/ 45  Feature/Mall/ReceiptMailSettings.php
0.0%  0/ 45  Feature/Payout/StoreUse.php
0.0%  0/ 47  Feature/Book/VendorMemoController.php
0.0%  0/ 49  Feature/Book/MissedSaleController.php
0.0%  0/ 50  Shared/Jobs/JobSchedule.php
0.0%  0/ 53  Feature/Book/VendorMemo.php
0.0%  0/ 58  Feature/Book/MissedSale.php
```

Every single new subsystem from this batch is at zero: the job runner, the job scheduler, the digest, the store-use money path, the books report, the reports controller, the receipt mailer. `JobQueue.php` is at 18.2%.

**This is a new finding (N1).** Coverage is nightly-only — it is not in `composer check` and not in `check.yml`. A pull request can add a money operation with 0% coverage and merge green. The 90% floor then reports success because the old code carries it.

---

## 4. Mutation testing — 436 killed, 0 survived (partial run)

`php bin/mutate.php`, sharded 8 ways. The run was stopped after ~35 minutes with shards still active, so this is a partial score, not the final nightly number.

```
killed:   436
survived: 0
```

Every mutant generated was killed. Where the suite covers code, the mutation gate is genuinely strong — this is real evidence, not a claim. But mutation only mutates lines that coverage executes, so the 19 files at 0% produce no mutants at all. The gate is strong exactly where it is least needed.

**Caveat, stated plainly:** running 8 shards on one host produced a spurious failure in `PostgresToolsTest::testAnInvalidContainerNameIsRefused`, because `passwordFiles()` globs `stall-pg-*` in the shared system temp directory (`tests/Feature/Backup/PostgresToolsTest.php:169`). CI shards across separate machines, so this does not affect CI. It is recorded here only as a low-severity note: **the unit suite is not safe to run concurrently on one host** (N2).

---

## 5. Findings proven by execution

Each of these was reproduced against a live database, not inferred.

### C4 — wipe permanently drops the FK — **PROVEN**

Fresh database, three FKs to `platform.tenants`:

```
owners_tenant_id_fkey
password_reset_requests_tenant_id_fkey
password_resets_tenant_id_fkey
```

Provisioned a tenant, ran `php bin/wipe-tenant.php throwaway`, re-queried:

```
owners_tenant_id_fkey
password_reset_requests_tenant_id_fkey
```

**Three before, two after, and nothing re-adds it.** The constraint is defined at `sql/000_platform.sql:473` and only applied on a fresh `provision-platform`.

Worse: this is not theoretical. The project's **own test suite** runs `wipe-tenant.php` (`tests/Integration/Dev/TenantResetTest.php` via `MallTenantReset`). After running `composer check`, the `consign` database was already missing `password_resets_tenant_id_fkey` — the gates themselves silently degrade the database they run against.

Also confirmed: `platform.owner_backups` has **no FK to `platform.tenants` at all** (`sql/000_platform.sql:334-341` defines only CHECK constraints). So `dropBackupTenantKey()` at `bin/wipe-tenant.php:94` is dead code — it queries for a constraint that does not exist and returns silently. The original finding's second half was wrong; the table has no FK to lose.

### C5 — store use double-posts — **PROVEN**

Called `StoreUse::record()` twice with identical arguments (same vendor, same amount 2500, same date, same description):

```
first journal:  01a1610a-e7a3-78a9-930a-28e79d0fbd1f
second journal: 01a1610a-e7b8-778a-b0da-63b98069b505
same journal?   NO — DOUBLE POST

store-use journals now in the ledger: 4
  store-use:b1d7d8534fb84bd3623b611695a5d156  debit=2500 credit=0
  store-use:b1d7d8534fb84bd3623b611695a5d156  debit=0 credit=2500
  store-use:d23ded9214d937316b36a00061dc09f3  debit=2500 credit=0
  store-use:d23ded9214d937316b36a00061dc09f3  debit=0 credit=2500

vendor_payable balance: 5000 (expected 2500 for one purchase)
store_purchases balance: 5000
```

**5,000 posted for a 2,500 purchase.** The random posting key defeats the ledger's own deduplication. This is the only money path in the system that behaves this way.

### C2 — no upgrade path, and deploy responds by wiping — **PROVEN**

Appended a single comment line to `sql/001_tenant.sql` (simulating any post-deploy schema fix), then ran the migration:

```
$ php bin/migrate.php tenant probe
001_tenant.sql changed after it was applied
EXIT=1
```

`bin/deploy-demo.sh:60-66` catches exactly that message and responds:

```bash
if [[ "$tenant_err" == *"changed after it was applied"* ]]; then
    "$php_bin" "${root}/bin/wipe-tenant.php" mall
fi
"$php_bin" "${root}/bin/provision-tenant.php" mall "Harbor Antique Mall"
```

**A one-line schema fix destroys the tenant.** The "append-only, forward-only" law is not merely violated — the automated response to a violation is data loss.

### H2 — a failed job is finished and never retried — **PROVEN**

Enqueued a job for a tenant that does not exist, then ran the exact `claim → handle → finish` path from `JobRunner::pass()`:

```
claimed: kind=reconcile-reports tenant=ghost attempts=1
after finish: finished=true attempts=1 error=tenant is not provisioned
re-claimable? NO — it will never run again
overdue() reports: 0
```

`finished_at` is set, `attempts` is incremented but never acted on, and `overdue()` reports **0** — the failed job is invisible to the only monitoring query in the system. This also proves **M8**: `overdue()` counts running jobs and ignores failed ones.

### H3 — enqueue race aborts the pass — **PROVEN**

Two sessions ran the exact `INSERT ... SELECT ... WHERE NOT EXISTS` from `JobQueue::enqueue()` concurrently:

```
[w1] pg_sleep ... (succeeded)
[w2] ERROR: duplicate key value violates unique constraint "jobs_tenant_kind_day_key"
     DETAIL: Key (tenant, kind, (payload ->> 'date'))=(probe, vendor-digest, 2026-10-21) already exists.
```

The second worker's `23505` propagates out of `enqueue()` and aborts the scheduling pass. `ON CONFLICT ... DO NOTHING` would remove this entirely.

### M9 — the web tier cannot enqueue — **PROVEN**

Live grants on `platform.jobs`:

```
stall        | DELETE,INSERT,REFERENCES,SELECT,TRIGGER,TRUNCATE,UPDATE
stall_app    | SELECT
stall_poster | SELECT
```

Attempting the insert as `stall_app`:

```
ERROR:  permission denied for table jobs
```

Only the superuser can enqueue. Any web-side enqueue fails at runtime.

### M1 — the phase test is vacuous — **PROVEN**

Moved `src/Shared/Jobs/` out of the tree entirely, then ran the two tests:

- `PhaseCallsTest` — **passed** with the whole job subsystem deleted. It asserts that a hardcoded string literal contains `'pass('`. It cannot fail.
- `StoreUseTest` — failed (`method_exists` returned false). So it is not vacuous, but it only asserts a method name exists; it does not test the double-post in C5.

### C1 — credential in history — **PROVEN**

```
$ git log --oneline -S'rtxlnmaxtzfjvjno' --all -- sql/
428baff Email sale receipts from the server or a mall Gmail account, ...
```

The secret is present in **19 commits**. Deleting the file does not delete the secret; history must be rewritten.

### C3 — wipe button on the live demo — **CONFIRMED**

```
$ curl -o /dev/null -w "%{http_code}" https://v2.perfectconsign.com/mall
200
```

`src/Shared/Web/layout.php:36` sets `$resetTestData` for slug `mall` + role `owner`; lines 256-262 render the danger form with a single `confirm()`. The demo is live and the button is compiled in.

### H8 / H9 — single call sites — **CONFIRMED**

- `Permission::allows` — 1 production call site: `src/Feature/Report/ReportsController.php:52`.
- `AuditLog` — 1 production call site: `src/Feature/Company/CompanyController.php:39`.

---

## 6. Correction: H6 is withdrawn

The original review claimed the obligation scanner was narrowed until it checked nothing, because `bin/prove-obligations.php:38` uses `$file > '001_tenant.sql'`.

**That finding is wrong.** Tested directly: removed `SELECT public.stall_seed_export_accounts();` from `sql/007_vendor_memo.sql` (the only call site) and ran the gate:

```
007_vendor_memo.sql adds a chart role and does not call stall_seed_export_accounts()
EXIT=1
```

The gate fires. `007_vendor_memo.sql` adds one chart role and is greater than `001_tenant.sql`, so the obligation is enforced there. `001_tenant.sql` adds 24 chart roles and is exempt, but the obligation is still satisfied downstream by 007.

**H6 is withdrawn.** The scanner is not blind. The residual observation is narrower and lower severity: the *rule* is now vacuous for `001_tenant.sql` itself, so a future chart role added to 001 would not be checked for the export-account call — but that is a latent maintenance risk, not a current defect.

This correction matters. It is exactly the kind of error that source-reading-only reviews produce, and it is why running the gates was worth the effort.

---

## 7. Revised scorecard

| | Original (read-only) | After execution |
|---|---|---|
| Critical | 5 | **5** (all confirmed) |
| High | 9 | **8** (H6 withdrawn) |
| Medium | 11 | **12** (N1 added) |
| Low | 6 | **7** (N2 added) |

**New findings from execution:**

- **N1 (medium)** — 19 files at 0.0% coverage, including every new money path and the entire job subsystem. The 90% floor is aggregate and coverage is nightly-only, not in `composer check`. New code merges green with zero tests.
- **N2 (low)** — the unit suite is not parallel-safe on one host: `passwordFiles()` globs `stall-pg-*` in the shared temp directory (`tests/Feature/Backup/PostgresToolsTest.php:169`). Harmless in CI (separate machines), but it means local sharded runs produce false failures.

**Unchanged conclusion:** the ledger kernel is genuinely strong — 89 `ENABLE ALWAYS` triggers survived the collapse, `account_balances` is still a view, 55 proof files pass, 436 mutants killed with zero survivors. The gates work. The problem is what the gates do not cover, and the five critical defects that a fully green `composer check` cannot see.

---

## 8. Reproducibility

```bash
# PHP 8.5 + PG 18.6, then:
composer install
export STALL_DB_HOST=127.0.0.1 STALL_DB_PORT=5436 STALL_DB_NAME=consign \
       STALL_DB_USER=stall STALL_DB_PASSWORD=stall \
       STALL_APP_PASSWORD=ci-app-password STALL_OWNER_PASSWORD=ci-owner-password \
       STALL_BACKUP_PASSWORD=ci-backup-password
php bin/provision-platform.php
php bin/enable-stall-app.php
composer check          # 819 tests, 4505 assertions, all green
php bin/coverage-run.php # 93.53%, 19 files at 0.0%
```

C4 reproduction:

```bash
php bin/provision-tenant.php throwaway "Throwaway"
psql -c "SELECT count(*) FROM pg_constraint WHERE contype='f' AND confrelid='platform.tenants'::regclass;"  # 3
php bin/wipe-tenant.php throwaway
psql -c "SELECT count(*) FROM pg_constraint WHERE contype='f' AND confrelid='platform.tenants'::regclass;"  # 2
```
