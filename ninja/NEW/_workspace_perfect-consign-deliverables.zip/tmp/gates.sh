#!/usr/bin/env bash
set -uo pipefail
cd /workspace/perfect-consign-v2 || exit 1
source /tmp/env.sh
export PGPASSWORD=stall
: > /tmp/t_status.log

run() {
  name="$1"; shift
  echo "START $name $(date +%H:%M:%S)" >> /tmp/t_status.log
  "$@" > "/tmp/t_${name}.log" 2>&1
  echo "END $name rc=$? $(date +%H:%M:%S)" >> /tmp/t_status.log
}

run freeze      php bin/check-migration-freeze.php
run maxlines    php bin/check-max-lines.php 500
run phpmd       php -d error_reporting="E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED" vendor/bin/phpmd src text phpmd.xml
run phpstan     php vendor/bin/phpstan analyse --memory-limit=512M
run unit        php vendor/bin/phpunit --testsuite unit
run integration php vendor/bin/phpunit --testsuite integration
run http        php vendor/bin/phpunit --testsuite http
run obligations php bin/prove-obligations.php
run race        php bin/prove-race.php
run prove       php bin/prove-suite.php
run tenant      php bin/prove-tenant.php
run worker      php bin/check-worker.php
echo ALLDONE >> /tmp/t_status.log
