#!/usr/bin/env bash
set -uo pipefail
cd /workspace/perfect-consign-v2
source /tmp/env.sh
export STALL_MAIL_FILE=/tmp/probe-mail2.txt
: > $STALL_MAIL_FILE
PORT=8098
php -S 127.0.0.1:$PORT -t public public/index.php > /tmp/host_srv.log 2>&1 &
SRV=$!
sleep 1.5
B=http://127.0.0.1:$PORT
csrf() { grep -o 'name="csrf" value="[^"]*"' | head -1 | sed 's/.*value="//;s/"//'; }

echo "=== H1 admin forgot with poisoned Host"
J=/tmp/h1.jar; rm -f $J
C=$(curl -s -c $J -b $J -H "Host: evil.example" $B/admin/forgot | csrf); echo "csrf=$C"
curl -s -c $J -b $J -o /dev/null -w "%{http_code} -> %{redirect_url}\n" -H "Host: evil.example" -d "csrf=$C&email=admin@example.test" $B/admin/forgot
sleep 1; grep -o 'http[s]*://[^ ]*' $STALL_MAIL_FILE | sort -u | head -3; echo "(mail bytes: $(wc -c < $STALL_MAIL_FILE))"

echo "=== H2 owner forgot with poisoned Host"
J=/tmp/h2.jar; rm -f $J
PAGE=$(curl -s -c $J -b $J -H "Host: evil.example" $B/mall/forgot); C=$(echo "$PAGE" | csrf); echo "csrf=$C"; echo "$PAGE" | grep -o 'name="[a-z_]*"' | sort -u | tr '\n' ' '; echo
curl -s -c $J -b $J -o /dev/null -w "%{http_code} -> %{redirect_url}\n" -H "Host: evil.example" -d "csrf=$C&username=owner" $B/mall/forgot
sleep 1; grep -o 'http[s]*://[^ ]*' $STALL_MAIL_FILE | sort -u | head -5; echo "(mail bytes: $(wc -c < $STALL_MAIL_FILE))"

echo "=== H3 X-Forwarded-Host"
J=/tmp/h3.jar; rm -f $J
C=$(curl -s -c $J -b $J -H "X-Forwarded-Host: evil2.example" $B/mall/forgot | csrf)
curl -s -c $J -b $J -o /dev/null -w "%{http_code}\n" -H "X-Forwarded-Host: evil2.example" -d "csrf=$C&username=owner" $B/mall/forgot
sleep 1; grep -o 'http[s]*://[^ ]*' $STALL_MAIL_FILE | sort -u | head -5
echo "=== mail tail"; tail -c 1200 $STALL_MAIL_FILE
kill $SRV
