\set ON_ERROR_STOP off
\echo === schema for mall tenant
SELECT schema_name FROM platform.tenants WHERE slug='mall' \gset
\echo :schema_name
SET search_path TO :schema_name, public;

\echo === P1: roles granted stall_vendor
SELECT r.rolname AS member FROM pg_auth_members m JOIN pg_roles r ON r.oid=m.member JOIN pg_roles g ON g.oid=m.roleid WHERE g.rolname='stall_vendor';

\echo === P2: grants on register_snaps for poster
SELECT grantee, string_agg(privilege_type, ',' ORDER BY privilege_type) FROM information_schema.role_table_grants WHERE table_schema=:'schema_name' AND table_name='register_snaps' GROUP BY grantee;

\echo === P3: grants on stall_vendor_* views
SELECT table_name, grantee, string_agg(privilege_type, ',' ORDER BY privilege_type) FROM information_schema.role_table_grants WHERE table_schema=:'schema_name' AND table_name LIKE 'stall_vendor%' GROUP BY 1,2 ORDER BY 1,2;

\echo === P4: as stall_poster, read vendor views for an arbitrary vendor by setting the GUC
SET ROLE stall_poster;
SELECT current_user;
SELECT set_config('stall.vendor_id', (SELECT id::text FROM vendors ORDER BY created_at LIMIT 1), false);
SELECT count(*) AS vendor_items_visible FROM stall_vendor_items;
SELECT set_config('stall.vendor_id', (SELECT id::text FROM vendors ORDER BY created_at DESC LIMIT 1), false);
SELECT count(*) AS other_vendor_items_visible FROM stall_vendor_items;
RESET ROLE;

\echo === P5: as stall_poster, UPDATE/DELETE register_snaps
SET ROLE stall_poster;
SELECT count(*) AS snaps_before FROM register_snaps;
UPDATE register_snaps SET posting_key = posting_key WHERE false;
DELETE FROM register_snaps WHERE false;
RESET ROLE;

\echo === P6: triggers on register_snaps / sale_lines
SELECT event_object_table, trigger_name, action_timing, event_manipulation FROM information_schema.triggers WHERE trigger_schema=:'schema_name' AND event_object_table IN ('register_snaps','sale_lines','journal','journal_lines','commission_rules') ORDER BY 1,2;

\echo === P7: commission_rules grants + GUC footprint
SELECT grantee, string_agg(privilege_type, ',' ORDER BY privilege_type) FROM information_schema.role_table_grants WHERE table_schema=:'schema_name' AND table_name='commission_rules' GROUP BY grantee;

\echo === P8: platform.admin tables grants
SELECT table_name, grantee, string_agg(privilege_type, ',' ORDER BY privilege_type) FROM information_schema.role_table_grants WHERE table_schema='platform' AND table_name LIKE 'admin%' GROUP BY 1,2 ORDER BY 1,2;

\echo === P9: wipe_tenant definition + who can execute
SELECT p.proname, pg_get_userbyid(p.proowner) AS owner, p.prosecdef, p.proacl FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='platform' AND p.proname IN ('wipe_tenant','enqueue_vendor_letter','grant_poster_jobs');

\echo === P10: as stall_poster can I call platform.wipe_tenant?
SET ROLE stall_poster;
SELECT platform.wipe_tenant('nonexistent-slug');
RESET ROLE;

\echo === P11: as stall_app, can I call wipe on nonexistent (guard message)?
SET ROLE stall_app;
SELECT platform.wipe_tenant('nonexistent-slug');
RESET ROLE;

\echo === P12: vendor_entry_tokens grants
SELECT grantee, string_agg(privilege_type, ',' ORDER BY privilege_type) FROM information_schema.role_table_grants WHERE table_schema=:'schema_name' AND table_name='vendor_entry_tokens' GROUP BY grantee;

\echo === P13: job_mail_sent grants
SELECT grantee, string_agg(privilege_type, ',' ORDER BY privilege_type) FROM information_schema.role_table_grants WHERE table_schema=:'schema_name' AND table_name='job_mail_sent' GROUP BY grantee;

\echo === P14: override fns
SELECT p.proname, p.prosecdef, p.proacl FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname=:'schema_name' AND p.proname LIKE 'stall_override%';

\echo === P15: admin_audit append-only check as stall_app
SET ROLE stall_app;
SELECT count(*) FROM platform.admin_audit;
DELETE FROM platform.admin_audit WHERE false;
UPDATE platform.admin_audit SET id=id WHERE false;
RESET ROLE;
