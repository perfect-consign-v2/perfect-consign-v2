#!/usr/bin/env bash
set -uo pipefail
cd /workspace/perfect-consign-v2 || exit 1
source /tmp/env.sh
export PGPASSWORD=stall

echo "=== DROP/CREATE DB ==="
psql -h 127.0.0.1 -p 5436 -U stall -d postgres -v ON_ERROR_STOP=1 \
  -c "DROP DATABASE IF EXISTS consign WITH (FORCE);" \
  -c "CREATE DATABASE consign;" 2>&1 | tail -3

echo "=== ROLES (drop stale) ==="
psql -h 127.0.0.1 -p 5436 -U stall -d postgres -tAc \
 "select rolname from pg_roles where rolname like 'poster_%' or rolname in ('stall_app','stall_backup','stall_worker','stall_poster');" \
 | while read -r r; do [ -n "$r" ] && psql -h 127.0.0.1 -p 5436 -U stall -d postgres -c "DROP ROLE IF EXISTS \"$r\";" >/dev/null 2>&1; done

echo "=== PROVISION PLATFORM ==="
php bin/provision-platform.php 2>&1 | tail -5; echo "platform_exit=${PIPESTATUS[0]}"
echo "=== ENABLE STALL APP ==="
php bin/enable-stall-app.php 2>&1 | tail -5; echo "enable_exit=${PIPESTATUS[0]}"
echo "=== PROVISION TENANT ==="
php bin/provision-tenant.php mall "Mall Demo" 2>&1 | tail -5; echo "tenant_exit=${PIPESTATUS[0]}"
echo "=== MIGRATE platform / tenant-all / platform-after ==="
php bin/migrate.php platform 2>&1 | tail -3
php bin/migrate.php tenant-all 2>&1 | tail -3
echo "=== SET PLATFORM ADMIN ==="
STALL_PLATFORM_ADMIN_EMAIL=admin@example.test STALL_PLATFORM_ADMIN_PASSWORD="Adm1n-Passw0rd-Long!" php bin/set-platform-admin.php 2>&1 | tail -3; echo "admin_exit=${PIPESTATUS[0]}"

echo "=== SCHEMAS ==="
psql -h 127.0.0.1 -p 5436 -U stall -d consign -tAc "select nspname from pg_namespace where nspname like 'tenant_%' or nspname='platform' order by 1;"
echo "=== platform tables ==="
psql -h 127.0.0.1 -p 5436 -U stall -d consign -tAc "select table_name from information_schema.tables where table_schema='platform' order by 1;"
echo "=== ROLES NOW ==="
psql -h 127.0.0.1 -p 5436 -U stall -d postgres -tAc "select rolname, rolsuper, rolinherit, rolcanlogin from pg_roles where rolname like 'stall%' or rolname like 'poster_%' order by 1;"
echo PROVISIONDONE
