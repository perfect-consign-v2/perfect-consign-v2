#!/usr/bin/env python3
"""Render a Markdown deliverable to styled HTML (navy/serif house style), then wkhtmltopdf."""
import sys, subprocess, pathlib, html
import markdown

CSS = """
@page { size: Letter; margin: 18mm 16mm 16mm 16mm; }
body { font-family: Georgia, 'Times New Roman', serif; font-size: 10.5pt; line-height: 1.45; color: #1b1f2a; }
h1 { font-size: 20pt; color: #0f2a4a; border-bottom: 2px solid #0f2a4a; padding-bottom: 6px; margin: 0 0 14px; }
h2 { font-size: 14.5pt; color: #0f2a4a; margin: 26px 0 8px; border-bottom: 1px solid #c7d0dc; padding-bottom: 3px; page-break-after: avoid; }
h3 { font-size: 11.5pt; color: #1f3d63; margin: 18px 0 6px; page-break-after: avoid; }
p { margin: 0 0 9px; text-align: justify; }
strong { color: #0f2a4a; }
code { font-family: 'DejaVu Sans Mono', Consolas, monospace; font-size: 8.6pt; background: #f1f4f8; padding: 0 3px; border-radius: 2px; }
pre { font-family: 'DejaVu Sans Mono', Consolas, monospace; font-size: 8.2pt; background: #f1f4f8; border-left: 3px solid #0f2a4a; padding: 8px 10px; white-space: pre-wrap; word-break: break-word; page-break-inside: avoid; }
pre code { background: none; padding: 0; }
table { border-collapse: collapse; width: 100%; margin: 8px 0 14px; font-size: 8.6pt; page-break-inside: auto; }
th { background: #0f2a4a; color: #fff; text-align: left; padding: 5px 6px; font-family: Helvetica, Arial, sans-serif; font-size: 8.4pt; }
td { border-bottom: 1px solid #d8dee8; padding: 4px 6px; vertical-align: top; }
tr { page-break-inside: avoid; }
tr:nth-child(even) td { background: #f7f9fc; }
ul, ol { margin: 0 0 10px 20px; }
li { margin-bottom: 3px; }
hr { border: 0; border-top: 1px solid #c7d0dc; margin: 18px 0; }
blockquote { border-left: 3px solid #c7d0dc; margin: 8px 0; padding: 2px 12px; color: #444; }
.foot { font-family: Helvetica, Arial, sans-serif; font-size: 8pt; color: #667; margin-top: 30px; border-top: 1px solid #c7d0dc; padding-top: 6px; }
"""

def render(md_path: str, foot: str) -> str:
    src = pathlib.Path(md_path).read_text(encoding="utf-8")
    body = markdown.markdown(src, extensions=["tables", "fenced_code", "sane_lists"])
    out = pathlib.Path(md_path).with_suffix(".html")
    out.write_text(
        f"<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(pathlib.Path(md_path).stem)}</title>"
        f"<style>{CSS}</style></head><body>{body}<div class='foot'>{html.escape(foot)}</div></body></html>",
        encoding="utf-8",
    )
    return str(out)

def pdf(html_path: str) -> str:
    out = str(pathlib.Path(html_path).with_suffix(".pdf"))
    subprocess.run(
        ["wkhtmltopdf", "--quiet", "--enable-local-file-access", "--page-size", "Letter",
         "--margin-top", "18mm", "--margin-bottom", "16mm", "--margin-left", "16mm", "--margin-right", "16mm",
         "--footer-center", "[page] / [topage]", "--footer-font-size", "8", "--footer-font-name", "Helvetica",
         html_path, out],
        check=True,
    )
    return out

if __name__ == "__main__":
    md, foot = sys.argv[1], sys.argv[2]
    h = render(md, foot)
    print(pdf(h))
