#!/usr/bin/env bash
set -uo pipefail
cd /workspace/perfect-consign-v2
source /tmp/env.sh
export STALL_MAIL_FILE=/tmp/probe-mail.txt
: > $STALL_MAIL_FILE
PORT=8097
php -S 127.0.0.1:$PORT -t public public/index.php > /tmp/admin_srv.log 2>&1 &
SRV=$!
sleep 1.5
J=/tmp/adm.jar; rm -f $J
B=http://127.0.0.1:$PORT
csrf() { grep -o 'name="csrf" value="[^"]*"' | head -1 | sed 's/.*value="//;s/"//'; }

echo "=== A1 admin login page"
C=$(curl -s -c $J -b $J $B/admin/login | csrf); echo "csrf=$C"
echo "=== A2 login"
curl -s -c $J -b $J -o /dev/null -w "%{http_code} -> %{redirect_url}\n" -d "csrf=$C&email=admin@example.test&password=Adm1n-Passw0rd-Long!" $B/admin/login
echo "=== A3 tenants list"
curl -s -c $J -b $J $B/admin/tenants -o /tmp/adm_tenants.html -w "%{http_code}\n"; grep -o 'action="/admin/tenants/[a-z]*/enter"' /tmp/adm_tenants.html | sort -u
C=$(cat /tmp/adm_tenants.html | csrf)
echo "=== A4 enter as owner of mall"
curl -s -c $J -b $J -o /dev/null -w "%{http_code} -> %{redirect_url}\n" -d "csrf=$C&role=owner" $B/admin/tenants/mall/enter
echo "=== A5 tenant dashboard reachable with same cookie"
curl -s -c $J -b $J -o /tmp/adm_dash.html -w "%{http_code}\n" $B/mall/dashboard; grep -o '<title>[^<]*' /tmp/adm_dash.html | head -1
echo "=== A6 admin still signed in alongside? (GET /admin/tenants)"
curl -s -c $J -b $J -o /tmp/adm_t2.html -w "%{http_code} -> %{redirect_url}\n" $B/admin/tenants; grep -c 'enter' /tmp/adm_t2.html
echo "=== A7 sign out of the TENANT; does admin survive?"
C2=$(cat /tmp/adm_dash.html | csrf); echo "tenant csrf=$C2"
curl -s -c $J -b $J -o /dev/null -w "%{http_code} -> %{redirect_url}\n" -d "csrf=$C2" $B/mall/logout
curl -s -c $J -b $J -o /tmp/adm_t3.html -w "after tenant logout, /admin/tenants: %{http_code} -> %{redirect_url}\n" $B/admin/tenants
echo "=== A8 re-login admin, enter as cashier, then admin logout; does tenant survive?"
C=$(curl -s -c $J -b $J $B/admin/login | csrf)
curl -s -c $J -b $J -o /dev/null -w "%{http_code}\n" -d "csrf=$C&email=admin@example.test&password=Adm1n-Passw0rd-Long!" $B/admin/login
C=$(curl -s -c $J -b $J $B/admin/tenants | csrf)
curl -s -c $J -b $J -o /dev/null -w "enter cashier: %{http_code} -> %{redirect_url}\n" -d "csrf=$C&role=cashier" $B/admin/tenants/mall/enter
C=$(curl -s -c $J -b $J $B/admin/tenants | csrf)
curl -s -c $J -b $J -o /dev/null -w "admin logout: %{http_code} -> %{redirect_url}\n" -d "csrf=$C" $B/admin/logout
curl -s -c $J -b $J -o /tmp/adm_pos.html -w "after admin logout, /mall/pos: %{http_code} -> %{redirect_url}\n" $B/mall/pos
echo "=== A9 host header poisoning of reset link"
C=$(curl -s -c $J -b $J $B/admin/forgot | csrf)
curl -s -c $J -b $J -o /dev/null -w "%{http_code}\n" -H "Host: evil.example" -d "csrf=$C&email=admin@example.test" $B/admin/forgot
sleep 1; grep -o 'http[s]*://[^ ]*reset[^ ]*' $STALL_MAIL_FILE | head -3; echo "(mail file lines: $(wc -l < $STALL_MAIL_FILE))"
echo "=== A10 owner forgot flow with poisoned Host"
C=$(curl -s -c $J -b $J $B/mall/forgot | csrf); echo "owner forgot csrf=$C"
curl -s -c $J -b $J -o /dev/null -w "%{http_code}\n" -H "Host: evil.example" -d "csrf=$C&username=owner" $B/mall/forgot
sleep 1; grep -o 'http[s]*://[^ ]*' $STALL_MAIL_FILE | sort -u | head
echo "=== A11 admin rate limit: 12 bad passwords"
for i in $(seq 1 12); do C=$(curl -s -c $J -b $J $B/admin/login | csrf); curl -s -c $J -b $J -o /dev/null -w "%{http_code} " -d "csrf=$C&email=admin@example.test&password=wrong$i" $B/admin/login; done; echo
C=$(curl -s -c $J -b $J $B/admin/login | csrf); curl -s -c $J -b $J -o /tmp/adm_lock.html -w "good pw after 12 bad: %{http_code} -> %{redirect_url}\n" -d "csrf=$C&email=admin@example.test&password=Adm1n-Passw0rd-Long!" $B/admin/login; grep -io 'locked[^<]*\|too many[^<]*\|wait[^<]*' /tmp/adm_lock.html | head -2
echo "=== A12 security headers on /admin/login"
curl -s -D - -o /dev/null $B/admin/login | grep -i "content-security\|x-frame\|strict-transport\|x-content-type\|referrer\|set-cookie" 
kill $SRV
