\set ON_ERROR_STOP off
SELECT schema_name FROM platform.tenants WHERE slug='mall' \gset
SET search_path TO :schema_name, public;
SET ROLE stall_poster;
\echo === item with a real commission rate and stock, in an open register session
SELECT id AS item_id, vendor_id, coalesce(commission_bps,-1) AS commission_bps, quantity, price_minor FROM items WHERE placement='consigned' AND quantity>0 ORDER BY (commission_bps IS NULL), created_at DESC LIMIT 1 \gset
\echo item :item_id bps :commission_bps qty :quantity
SELECT id AS sess FROM register_sessions WHERE closed_at IS NULL ORDER BY opened_at DESC LIMIT 1 \gset
\echo session :sess
SELECT mall.tax_bps FROM mall \gset
\echo mall tax_bps :tax_bps

\echo === S1: client claims commission 0 and tax 0 on a 50.00 sale of an item that carries commission
INSERT INTO register_snaps (posting_key, session_id, business_date, item_id, price_minor, tax_minor, commission_minor, commission_bps, tax_bps, quantity)
VALUES ('aaaaaaaa-0000-4000-8000-00000000a001', :'sess', current_date, :'item_id', 5000, 0, 0, 0, 0, 1);
SELECT stall_sync_snap('aaaaaaaa-0000-4000-8000-00000000a001') AS journal_no;
SELECT status, refusal, journal_no FROM register_snaps WHERE posting_key='aaaaaaaa-0000-4000-8000-00000000a001';
SELECT jl.line_no, a.name, jl.debit_minor, jl.credit_minor, jl.subledger_ref FROM journal_lines jl JOIN journals j ON j.id=jl.journal_id JOIN accounts a ON a.id=jl.account_id WHERE j.posting_key='aaaaaaaa-0000-4000-8000-00000000a001' ORDER BY line_no;
SELECT price_minor, commission_minor, tax_minor FROM sale_lines sl JOIN journals j ON j.id=sl.journal_id WHERE j.posting_key='aaaaaaaa-0000-4000-8000-00000000a001';

\echo === S2: item rate after the sync (was :commission_bps) and mall tax (was :tax_bps)
SELECT commission_bps FROM items WHERE id=:'item_id';
SELECT tax_bps FROM mall;

\echo === S3: replay the same key -> idempotent?
SELECT stall_sync_snap('aaaaaaaa-0000-4000-8000-00000000a001') AS journal_no_again;
SELECT count(*) FROM journals WHERE posting_key='aaaaaaaa-0000-4000-8000-00000000a001';

\echo === S4: client claims commission GREATER than price (vendor owes store)
SELECT id AS item2 FROM items WHERE placement='consigned' AND quantity>0 AND id<>:'item_id' ORDER BY created_at DESC LIMIT 1 \gset
INSERT INTO register_snaps (posting_key, session_id, business_date, item_id, price_minor, tax_minor, commission_minor, commission_bps, tax_bps, quantity)
VALUES ('aaaaaaaa-0000-4000-8000-00000000a002', :'sess', current_date, :'item2', 1000, 0, 5000, 10000, 0, 1);
SELECT stall_sync_snap('aaaaaaaa-0000-4000-8000-00000000a002') AS journal_no;
SELECT status, refusal FROM register_snaps WHERE posting_key='aaaaaaaa-0000-4000-8000-00000000a002';

\echo === S5: poster can rewrite a posted snap row after the fact
UPDATE register_snaps SET price_minor = 1 WHERE posting_key='aaaaaaaa-0000-4000-8000-00000000a001';
SELECT price_minor, status FROM register_snaps WHERE posting_key='aaaaaaaa-0000-4000-8000-00000000a001';
DELETE FROM register_snaps WHERE posting_key='aaaaaaaa-0000-4000-8000-00000000a001';
SELECT count(*) AS remaining FROM register_snaps WHERE posting_key='aaaaaaaa-0000-4000-8000-00000000a001';
RESET ROLE;
